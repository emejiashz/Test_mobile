'''
Created on 11 may. 2018

@author: MD432339
'''
import unittest
from src.functions.Functions import Functions as Selenium

class set_Values():

    Selenium().Modificar_XML_Enviroments()
        
if __name__ == "__main__":
    unittest.main()