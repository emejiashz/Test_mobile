from lettuce import *
import time
from src.utils.functions import CommonFunctions

@steps
class steps(CommonFunctions):
    
    @step('Open Google')
    def step_Open(self):
        print("Hola Google")
        self.driver = self.abrirNavegador("www.google.com")
        
    @step('Cuento hasta 5')
    def step_Cuento_5(self,context):
        time.sleep(5)
    
    @step('Cierro el browser')
    def step_Cierro(self, context):
        print("Chao Google")
        self.driver.quit()