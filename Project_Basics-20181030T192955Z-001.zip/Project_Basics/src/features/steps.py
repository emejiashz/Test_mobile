from behave import *
import time
import unittest


class steps_definitions():

    @given('Open Google')
    def step_Open(self):
        print("Hola Google")

    @when('Cuento hasta 5')
    def step_Cuento_5(self):
        time.sleep(10)

    @then('Cierro el browser')
    def step_Cierro(self):
        print("Chao Google")



if __name__ == "__main__":
    unittest.main()