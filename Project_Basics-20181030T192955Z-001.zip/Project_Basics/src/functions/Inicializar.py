# -*- coding: utf-8 -*-
   
class Inicializar():
    
    #BROWSER DE PRUEBAS
    NAVEGADOR = u"CHROME_headless"
    
    #DIRECTORIO DE LA EVIDENCIA
    Path_Evidencias = u"C:/datos/homo/raet/"
    
    #HOJA DE DATOS EXCEL
    Excel= u"../data/Data.xlsx"




    